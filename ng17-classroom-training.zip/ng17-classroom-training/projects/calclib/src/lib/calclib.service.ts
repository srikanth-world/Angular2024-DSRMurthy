import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalclibService {

  constructor() {
   }

   getIntAmount(p:number,n:number,r:number){
    return (p*n*r)/100
   }
}
