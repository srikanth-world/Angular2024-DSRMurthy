import { Component } from '@angular/core';
import { CalclibService } from './calclib.service';

@Component({
  selector: 'lib-calclib',
  template: `
   <div class="bg-warning text-center">
    <h3>Interest Calculator</h3>
    <button class="btn btn-success" (click)="calculate()">Calculate</button>
    <h4 class="bg-primary text-light">Amount: {{amount}}</h4>
   </div>
  `,
  styles: ``
})
export class CalclibComponent {
  constructor(private cs:CalclibService){}
  amount:number=0
  calculate(){
     this.amount=this.cs.getIntAmount(50000,10,9)
  }

}
