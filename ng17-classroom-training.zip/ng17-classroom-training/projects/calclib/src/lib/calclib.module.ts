import { NgModule } from '@angular/core';
import { CalclibComponent } from './calclib.component';



@NgModule({
  declarations: [
    CalclibComponent
  ],
  imports: [
  ],
  exports: [
    CalclibComponent
  ]
})
export class CalclibModule { }
