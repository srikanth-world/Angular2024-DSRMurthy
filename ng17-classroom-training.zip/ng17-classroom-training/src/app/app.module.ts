import { NgModule,ApplicationRef } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { ReactiveFormsModule } from '@angular/forms'; //rxjs
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BindingComponent } from '../learning/binding/binding.component';
import { FormsModule } from '@angular/forms';
import { DIModule } from '../learning/di/di.module';
import { TrackbyComponent } from '../learning/binding/trackby.component';
import { UserComponent } from './user/user.component';
import { InterCompModule } from '../learning/dataflow/intercomp.module';
import { ChildComponent, LifeCycleComponent } from '../learning/lifecycle/complifecycle';
import { InjectComponent } from '../learning/dynamic/inject.component';
import { SignalComponent } from '../learning/binding/signal.component';
import { WeatherComponent } from '../learning/http/weather.component';
import { HttpComponent } from '../learning/http/http.component';
import { NotifierComponent } from '../learning/rx-intercomp/notifier.component';
import { ConsumerComponent } from './consumer.component';
import { HomeComponent } from '../learning/rx-intercomp/home/home.component';
import { SPAModule } from '../spa/spa.module';
import { CalclibModule } from '../../projects/calclib/src/public-api';
import { ParentComponent } from '../learning/ngcontent/parent.component';
import { ButtonComponent } from '../learning/ngcontent/button.component';
import { CardComponent } from '../learning/ngcontent/card.component';
import { RealtimeModule } from '../learning/ngcontent/realtime/realtime.module';
import { SecurityComponent } from '../learning/xss/security.component';


@NgModule({
  declarations: [
    AppComponent,BindingComponent,TrackbyComponent,
    LifeCycleComponent,ChildComponent,InjectComponent,
    SignalComponent,WeatherComponent,HttpComponent,
    NotifierComponent,ConsumerComponent,HomeComponent,

    ParentComponent,ButtonComponent,CardComponent,
    SecurityComponent
  ],
  imports: [
    BrowserModule, FormsModule,DIModule,
    AppRoutingModule,InterCompModule,
    UserComponent,
    ReactiveFormsModule,HttpClientModule,
    SPAModule,

    CalclibModule,
    RealtimeModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  //profiling ,    web components   <boa-calculator> register
  /*
   constructor(private appRef:ApplicationRef){
    const originalTick=appRef.tick
    appRef.tick=function(){
      const winPerf=window.performance
      const start=winPerf.now()
      const retValue=originalTick.apply(this) //now you  render actual DOM
      const end=winPerf.now()
      const runtime=end-start
      window.console.log(` CDS took ${runtime}ms `)
      return retValue
    }
   }*/
 }
