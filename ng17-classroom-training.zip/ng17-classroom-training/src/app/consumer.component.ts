import { Component, OnDestroy, OnInit } from '@angular/core';

import { Subscription } from 'rxjs';
import { MessagingService } from '../learning/rx-intercomp/services/messaging.service';

@Component({
  selector: 'app-consumer',
  template: `
  <div>
    <h3>I am consumer component</h3>
    @if(response){
      <div class="alert  alert-primary">
    <marquee>
       <h4 class="text-warning">{{response.data}}</h4>
    </marquee>
   </div>
    }

</div>
  `
})
//consumer
export class ConsumerComponent implements OnInit , OnDestroy{
  constructor(private ms:MessagingService) { }
  response:any
  subsriber:Subscription | undefined


  ngOnInit():void {
     this.subsriber=this.ms.getStockInfo().subscribe( (resp:any)=>{
      this.response=resp
     })
  }

  ngOnDestroy(): void {
      this.subsriber?.unsubscribe
  }
}
