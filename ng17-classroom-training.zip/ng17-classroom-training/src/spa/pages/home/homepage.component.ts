import { Component, OnInit } from '@angular/core';

@Component({
  template: `
  <div class="bg-warning text-center">
    <h1>Customers Management Project </h1>
    <h3>Bank of America CMS</h3>
    <marquee>
      <h4 class="bg-danger text-warning">News: Bank of America offers new mutual funds </h4>
    </marquee>
</div>
  `
})

export class HomePageComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
