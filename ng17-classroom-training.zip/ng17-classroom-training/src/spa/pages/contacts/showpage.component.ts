import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({

  template: `
    <h4 class="bg-primary text-light">
      You have selected : {{name}}
     </h4>
     <p>Show more details here about {{name}}</p>
  `
})

export class ShowPageComponent implements OnInit {
  constructor(private route:ActivatedRoute) { }
  name:string | undefined

  ngOnInit() {
    this.name=this.route.snapshot.params['selected']
    //http.get(url+name).subcribe(rsp=>update state)

  }
}
//params={selected:'murthy',city:'chennai'}
