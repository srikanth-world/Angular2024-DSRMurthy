import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service';
import { User } from '../../services/user';

@Component({

  templateUrl: './loginpage.component.html'
})

export class LoginPageComponent implements OnInit {
  constructor(private _service:LoginService) { }
  status:boolean=false
  flag:boolean=false
  errorMsg:any=' '
  user:User=new User('murthy','welcome')//JSON binding
  login(){
    if (!this._service.login(this.user)){
        this.errorMsg="Sorry... invalid credentials"
    }else{
      this.status=true
    }
  }
  logout(event:any){
     window.alert("You are successfully logged out.")
     this.flag=true
     this._service.logout()
  }

  ngOnInit() { }
}
