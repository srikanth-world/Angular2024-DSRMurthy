import { NgModule } from '@angular/core';
import { ProfileComponent } from './profile.component';
import { CommonModule } from '@angular/common';
import { ProfileRouterModule } from './profile.routes';


@NgModule({
  imports: [CommonModule,ProfileRouterModule],
  exports: [ProfileComponent],
  declarations: [ProfileComponent],
  providers: [],
})
export class ProfileModule { }
