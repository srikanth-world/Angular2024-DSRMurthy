import { Component, OnInit } from '@angular/core';


@Component({
  template: `
  <h4 class="bg-dark text-light"> About Bank of America</h4>
  <p> Bank of America started in the year .......</p>
  <p>put more stuff here</p>

  `
})

export class ProfileComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
