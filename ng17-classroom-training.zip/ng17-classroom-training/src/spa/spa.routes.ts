import { RouterModule,Routes } from "@angular/router";
import { HomePageComponent } from "./pages/home/homepage.component";
import { PageNotFoundComponent } from "./pages/notfound/notfoundpage.component";
import { LoginPageComponent } from "./pages/login/loginpage.component";
import { ContactListComponent } from "./pages/contacts/contactlist.component";
import { ShowPageComponent } from "./pages/contacts/showpage.component";
import { AuthGuard } from "./services/guards/auth.gurard";
import { LoadGuard } from "./services/guards/load.guard";

const customRoutes:Routes= [
 {path:'',component:HomePageComponent},
 {path:'login',component:LoginPageComponent},
 {path:'contacts',  canActivate:[AuthGuard],  component:ContactListComponent},
 {path:'show/:selected',component:ShowPageComponent},

 {path:'profile', canLoad:[LoadGuard], loadChildren: ()=> import('./profile/profile.module')
                          .then(m=> m.ProfileModule)},

 {path:'**', component:PageNotFoundComponent}
]

export const SPARouterModule=RouterModule.forRoot(customRoutes)
