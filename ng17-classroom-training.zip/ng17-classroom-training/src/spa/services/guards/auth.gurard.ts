import { ActivatedRouteSnapshot, CanActivateFn, RouterStateSnapshot }
  from "@angular/router";
import { Session } from "../globals";
export const AuthGuard:CanActivateFn =(
  route:ActivatedRouteSnapshot,
  state:RouterStateSnapshot
)=>{

  if (Session.authenticated){
    alert("Welcome to dashboard ")
    return true
  }
  else{
    alert("Sorry........ you must authenticate to see the page")
    return false
  }
}
