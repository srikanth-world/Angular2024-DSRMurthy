//canload = canMatch  =>canload+canactivate

import { Injectable } from '@angular/core';
import { CanLoad,Route } from '@angular/router';
import { Session } from '../globals';
//canLoadFn()

@Injectable({providedIn: 'root'})
export class LoadGuard implements CanLoad {
  constructor() { }
  canLoad(route:Route) {
    if (Session.authenticate){
      alert("Lazy loading the profile")
      return true
    }
    else{
      return false
    }
  }
}
