import {Contact} from './contact'

//global data
export const CONTACTS:Contact[]=[
  {name:'Sriram',email:'murthy@gmail.com',phone:'43533232'},
  {name:'Murthy',email:'m.sri.@gmail.com',phone:'43545232'},
  {name:'Lalitha',email:'lalitha@gmail.com',phone:'98433232'},
  {name:'Mallik',email:'Mallik@gmail.com',phone:'94833232'}

]
