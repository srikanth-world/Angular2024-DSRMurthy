import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from './user';

import {Session} from './globals'
import { Router } from '@angular/router';

//mock data
const users=[
  new User('murthy','welcome'),
  new User('rajesh','hi')
]

//global data binding
@Injectable({providedIn: 'root'})
export class LoginService {
  constructor(private http:HttpClient,private _route:Router) { }
 private authenticatedUser:User | undefined
  login(user:User){
    //http.post(url,user)  header:[sso,sessionid,username, role,timeout]
     this.authenticatedUser=users.find( (u)=> u.username===user.username)
     if (this.authenticatedUser && this.authenticatedUser.password===user.password){
      //create session (global session)
      //resp.headers['sso']
      window.localStorage.setItem('user',user.username) //cokieeee
      Session.authenticated=true
      Session.username=user.username
      Session.sso='fs3kljfsd0ksd3-lfsdk3-lfksdfkllksf33332'
      Session.sessionID='39393292923lkfjsdlf'
      this._route.navigate(['contacts'])
      return true
     }
     return false
  }
  logout(){
    localStorage.removeItem("user")
    Session.authenticated=false
    Session.sso=null
    this._route.navigate(['/login'])
  }


}
