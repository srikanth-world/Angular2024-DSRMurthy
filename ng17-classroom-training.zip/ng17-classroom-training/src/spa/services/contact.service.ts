import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CONTACTS } from './mock-contacts';

@Injectable({providedIn: 'root'})
export class ContactService {
  constructor(private http:HttpClient) { }

  getContacts(){
    //return http.get(url).toPromise(resolve,reject)
    return Promise.resolve(CONTACTS)
  }
  //........
}
