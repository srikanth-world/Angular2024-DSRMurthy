import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SPARouterModule } from './spa.routes';
import { SPAComponent } from './spa.component';
import { HomePageComponent } from './pages/home/homepage.component';
import { PageNotFoundComponent } from './pages/notfound/notfoundpage.component';
import { LoginPageComponent } from './pages/login/loginpage.component';
import { ContactListComponent } from './pages/contacts/contactlist.component';
import { ShowPageComponent } from './pages/contacts/showpage.component';



@NgModule({
  imports: [CommonModule,FormsModule,SPARouterModule],
  exports: [SPAComponent],
  declarations: [SPAComponent,HomePageComponent,
    PageNotFoundComponent,LoginPageComponent,ContactListComponent,
    ShowPageComponent
  ],
  providers: [],
})
export class SPAModule { }
