import { Component, OnInit,EventEmitter,
  Output, Input} from '@angular/core';
//model
interface IPriceQuote{
  stockSymbol:string,
  lastPrice:number
}
interface ILogger{
  log(msg:string):void
}

//parent component
@Component({
  selector: 'app-stock',
  template: `
  <div class="bg-light">
    <h3>Parent Component received: {{stockSymbol}}  - {{price | currency:'USD'}} </h3>

    <price-quoter (lastPriceEvent)="handler($event)"></price-quoter>

    <notifier [info]="stockInfo"></notifier>
</div>
  `
})
//{info:stockInfo}
export class StockComponent implements OnInit {
  constructor() { }
  stockSymbol:string=' '
  price:number=0
  stockInfo:IPriceQuote={'stockSymbol':' ','lastPrice':0}
  //bookTkt()//http

  handler(event:IPriceQuote){
    this.stockSymbol=event.stockSymbol
    this.price=event.lastPrice
    this.stockInfo=event
  }

  ngOnInit() { }
}
//=========================================

@Component({
  selector: 'price-quoter',
  template: `
  <div class="bg-secondary text-light">
    <h3>Child - Pricequoter component:
    {{company}}  -  {{price | currency:'USD'}}
    </h3>
</div>
  `
})

export class PriceQuoterComponent implements OnInit,ILogger {
  log(msg: string): void {
   console.log(msg)
  }

  @Output()
  lastPriceEvent:EventEmitter<IPriceQuote> = new EventEmitter()
  //mailSentEvent:EventEmitter<any>=new EventEmitter()

  company:string='Bank of America'
  price:number=0

  constructor() {
    window.setInterval( ()=>{
          //http.get(url+this.company)   or websocket(uri).onMessage(msg=>do work)
          let priceQuote:IPriceQuote={
              stockSymbol:this.company,
              lastPrice:100*Math.random()
          }

          this.price=priceQuote.lastPrice
          this.lastPriceEvent.emit(priceQuote)
    },1000)
   }


  ngOnInit() { }
}

//=================================


@Component({
  selector: 'notifier',
  template: `
   <div class="bg-success text-light">
    <h3>Child - Notifier component:
    {{info.stockSymbol}}  -  {{info.lastPrice | currency:'USD'}}
    </h3>
</div>

  `
})

export class NotifierComponent implements OnInit {
  constructor() { }

  @Input()
  info:IPriceQuote={'stockSymbol':' ','lastPrice':0}

  ngOnInit() { }
}

