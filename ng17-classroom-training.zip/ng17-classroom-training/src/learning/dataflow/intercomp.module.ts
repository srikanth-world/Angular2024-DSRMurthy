import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NotifierComponent,
   PriceQuoterComponent, StockComponent } from './dataflow.component';



@NgModule({
  imports: [CommonModule],
  exports: [StockComponent],
  declarations: [StockComponent,PriceQuoterComponent,NotifierComponent],
  providers: [],
})
export class InterCompModule { }
