import { Component, OnInit,signal,computed,effect } from '@angular/core';
import { single } from 'rxjs';

@Component({
  selector: 'app-signal',
  template: `
  <div class="bg-light">
    <h3>Working with Signals</h3>
    <h4>Fullname : {{fullName()}}</h4>
    FirstName: <input type="text"  [(ngModel)]="firstName"
    value="Not bindable to signal"/>
    <br/>
    <button class="btn btn-success"
         (click)="setName('Mallika')">Change name
      </button>
</div>
  `
})

export class SignalComponent implements OnInit {
   firstName=signal("Murthy")
   lastName=signal("Srirama")
   fullName=computed(  ()=> ` ${this.firstName()}  ${this.lastName()}`)

   setName(newName:string){
      this.firstName.set(newName)
   }

  constructor() {
      effect( ()=>console.log(`Name is changed to ${this.fullName()} `) )
   }
  ngOnInit() { }
}

