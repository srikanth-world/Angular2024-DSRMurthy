import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html'
})

export class BindingComponent implements OnInit {
  constructor() { }
  username:string='Murthy'

  //mocked data (REST API)
  customers:any=[
    {id:101,name:'Murthy','balance':50000},
    {id:102,name:'Kiran','balance':45000},
    {id:103,name:'Lalitha','balance':90000},
    {id:104,name:'ramu','balance':10000}
  ]

  clicked:boolean=false
  clickedItem:any={name:'  ',balance:0}
  onItemClicked(item:any){
    this.clicked=true
    this.clickedItem=item
  }

  trackById(index:number, item:any){
    return item.id
  }
  ngOnInit() { }
}
