import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { StockComponent } from './stock.component';

@Component({
  selector: 'app-inject',
  template: `
   <h2 class="container text-center">Dynamic injection of Component</h2>
   <button class="btn btn-primary" (click)="getInfo()" [disabled]="flag"> Get Stock Info</button>
  `
})

export class InjectComponent implements OnInit {
  constructor(private vcr:ViewContainerRef) { }
  flag:boolean=false
  getInfo(){
    //if (isRole='admin')
    const hostview=this.vcr.createComponent(StockComponent)
    hostview.changeDetectorRef.detectChanges() // data binding and rerender (stablising)
    this.flag=true
  }
  ngOnInit() { }
}
