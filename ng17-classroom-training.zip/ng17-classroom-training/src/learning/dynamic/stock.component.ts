import { Component, OnInit } from '@angular/core';
import { StockService } from './stock.service';

@Component({

  template: `
     <div class="container bg-dark text-light">
      <marquee>
         <h3>Message: {{invoke()}}</h3>
      </marquee>
     </div>
  `
})

export class StockComponent implements OnInit {
  constructor(private ss:StockService) { }
  invoke(){
    return this.ss.getStock('Bank of America')
  }
  ngOnInit() { }
}
