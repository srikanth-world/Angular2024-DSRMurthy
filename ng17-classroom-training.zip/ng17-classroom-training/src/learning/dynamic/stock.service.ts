import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})
export class StockService {
  constructor() { }
  getStock(stockSymbol:string){
    //http.get(url) or web socket
    return `For ${stockSymbol}  -  stock value is $568.45 `
  }
}
