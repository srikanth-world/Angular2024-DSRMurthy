//model/object model/entity/ DTO    ORM
export class Customer{
  constructor(
      public id:number,
      public name:string,
      public email:string,
      public balance:number
  ){}

}

