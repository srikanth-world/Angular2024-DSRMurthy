import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { CustomerComponent } from './customer.component';
import { CustomerService } from './customer.service';



@NgModule({
  imports: [CommonModule],
  exports: [CustomerComponent],
  declarations: [CustomerComponent],
  providers: [CustomerService],
})
export class DIModule { }
