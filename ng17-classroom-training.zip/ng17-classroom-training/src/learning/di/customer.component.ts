import { Component, OnInit } from '@angular/core';
import { CustomerService } from './customer.service';

@Component({
  selector: 'app-di',
  template: `
   <div class="container">
    <h3>Customer Details</h3>
    <h4>id: {{customer.id}}</h4>
    <h4>name: {{customer.name}}</h4>
    <h4>email: {{customer.email}}</h4>
    <h4>balance: {{customer.balance}}</h4>
</div>
  `,
  //providers:[ CustomerService]
})

export class CustomerComponent implements OnInit {
  //var cs=new Customer()
  constructor( private cs:CustomerService) { }
  customer:any
  ngOnInit() {
    this.customer=this.cs.getCustomer(1001)
   }
}
/*
   life time of service
   1. component level
   2. module level
   3. global level
*/
