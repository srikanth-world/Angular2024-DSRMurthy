
import { Injectable } from '@angular/core';
import { Customer } from './customer';

interface ILogger{
  logMsg(msg:string):void
}

@Injectable()
export class CustomerService implements ILogger {
  constructor() { }
  logMsg(msg: string): void {
    //http.post(url,msg)
    console.log(msg)
  }
  getCustomer(id:number):Customer{
    //http.get(url+id).subscribe((resp=>console.log(resp))
    this.logMsg(` some one called getCustomer with id : ${id}`)
    return new Customer(1001,'Murthy','murthy@gmail.com',45000)

  }

}
