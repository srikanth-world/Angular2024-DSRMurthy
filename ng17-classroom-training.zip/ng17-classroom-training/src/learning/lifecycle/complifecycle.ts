import { ChangeDetectionStrategy, ChangeDetectorRef,
  Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-lifecycle',
  template: `
  <div class="container bg-warning">
    <h3> Customer Search: <input type="text" [(ngModel)]="search"></h3>
    <child [search]="search"></child>
</div>
  `
})
//parent   {'search':search}
export class LifeCycleComponent implements OnInit {
  search:string="murthy"
  constructor() { }

  ngOnInit() { }
}
//===========================================

@Component({
  selector: 'child',
  template: `
  <div class="bg-success text-light">
    <h3> Search Text:  {{search}}</h3>

    <h4 class="bg-primary text-light">
      {{counter}}
    </h4>

</div>
  `,
  changeDetection:ChangeDetectionStrategy.OnPush
})
//render will happen only when new node is added to ShadowDOM or
// when we call detectChanges() or when event is fired
export class ChildComponent implements OnInit,OnChanges {
  @Input()
  search:string=' '
  counter:number=0

  //1. constructor
  constructor(private cd:ChangeDetectorRef) {
    console.log(` In Constructor: ${this.search}`) //empty
   // this.cd.detach()

   }
     //2.ngOnChanges
    ngOnChanges(changes: SimpleChanges): void {
      //fired every time when state changes, do validations, loginfo...http.get(url+search)
      console.log(` In nOC: ${this.search}`)

      for(let key in changes){
        console.log(` ${key} changed)
          - Current: ${changes[key].currentValue}
          - Previous: ${changes[key].previousValue}
          `)
      }
    }
    //3.nOI
  ngOnInit() {
    // fired only once, make http rest api calls here with this.search,
    // subcribe to web sockets  , observable initiate events
    console.log(` In nOI: ${this.search}`)
     //http.get(url+this.search)
/*
      window.setTimeout( ()=>{
             this.cd.reattach()
      },5000)
*/
       window.setInterval( ()=>{
             ++this.counter
             console.log(` Counter value  : ${this.counter}`)
       },1000)


  }
  //4, ngDoCheck
     ngDoCheck():void{
      //CDS - to decide weather to render DOM or NOT, fired every time
      console.log(` In nDC : ${this.search}`)
     // this.cd.detectChanges()

      /*
      if (this.search.length===10){
          this.cd.detectChanges()// force update
      }
      */
     }


     ngAfterViewChecked(){
      //fired every time, apply UI logic  , Real DOM is ready
      //javascript, jquery ........
      console.log(` In ngAVC : ${this.search}`)
     }
     ngOnDestroy():void{
      // fired only once when we remove component from shadow dom
      // handle memory leaks, clean the cache, unsubscribe web sockets/observable
      console.log(` In nOD  is fired.. clean here`)
     }
}
