import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-xss',
  templateUrl: `./security.component.html`
})

export class SecurityComponent implements OnInit {
  constructor() { }
  username:string=' '


  ngOnInit() { }
}
