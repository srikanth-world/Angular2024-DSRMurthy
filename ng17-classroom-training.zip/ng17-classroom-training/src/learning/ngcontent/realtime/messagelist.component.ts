import { Component } from "@angular/core";
//parent
import { Message } from "./message.component";
//entry point
@Component({
  selector: 'app-realtime',
  template: `
<message-form (msgCreated)="addMessage($event)"></message-form>

<message *ngFor="let j of messages" [message]="j">
  <span class="category">{{ j.category }}?</span>
  <h3 class="punchline">{{ j.punchline }}</h3>
</message>
  `

})
export class MessageListComponent {
  messages: Message[];

  constructor() {
    this.messages = [
      new Message("IT", "Angular 18 is coming..."),
      new Message("General", "Omicron is gone"),
      new Message("Stocks", "Stock market is picking up’"),
    ];
  }

  addMessage(event:Message) {
    this.messages.push(event);
  }
}


