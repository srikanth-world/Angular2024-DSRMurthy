import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {MessageComponent } from './message.component';
import { MessageListComponent } from './messagelist.component';
import { MessageFormComponent } from './messageform.component';



@NgModule({
  imports: [CommonModule],
  exports: [MessageListComponent],
  declarations: [MessageListComponent,MessageFormComponent,
     MessageComponent],
  providers: [],
})
export class RealtimeModule { }
