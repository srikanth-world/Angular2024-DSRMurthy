
import {Component, EventEmitter, Output} from '@angular/core';
import { Message } from './message.component';

@Component({
  selector: 'message-form',
  templateUrl: './messageform.component.html',
  styleUrls: [
    './messageform.component.css'
  ]
})
export class MessageFormComponent {
  @Output()
  msgCreated = new EventEmitter<Message>();

  createMessage(category: string, punchline: string) {
    this.msgCreated.emit(new Message(category, punchline));
  }
}
