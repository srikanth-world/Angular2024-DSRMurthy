import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content',
  template: `
     <app-btn>
      <h4 class="btn btn-success">Save</h4>
    </app-btn>
    <app-btn>
      <h4 class="btn btn-warning"> <b>Delete</b></h4>
    </app-btn>
    <app-btn (click)="handler()" >
      <h4 class="btn btn-danger"> <i>Update</i></h4>
    </app-btn>
      <br/><br/>
      <h3>Multiple slots</h3>

       <app-card>
            <header> <h2>Angular 17</h2></header>
            <body><h4>One Framework for mobile and desktop</h4></body>
            <footer><a href="#">Super-powered by Google</a> </footer>
      </app-card>

        <app-card>
            <header> <h2>React 18.x</h2></header>
            <body><h4>A javascript library for buding rich and fast UI</h4></body>
            <footer><a href="#">Facebook open source library</a> </footer>
        </app-card>
  `
})

export class ParentComponent implements OnInit {
  constructor() { }
  handler(){
    alert('Thanks for update')
  }

  ngOnInit() { }
}
