import { Component, OnInit } from '@angular/core';
//child
@Component({
  selector: 'app-card',
  template: `
    <div class="card">
      <div class="heading">
         <ng-content select="header"></ng-content>
      </div>
      <div class="body">
         <ng-content select="body"></ng-content>
      </div>
      <div class="footer">
         <ng-content select="footer"></ng-content>
      </div>
    </div>
  `,
  styles:[
     ` .card { min-width:300px; margin:5px; float:left}

       .footer {background:black; color:white}
       .body {background:lightgreen}
     `
  ]
})

export class CardComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
