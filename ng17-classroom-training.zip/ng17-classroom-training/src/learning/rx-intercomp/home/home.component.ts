import { Component, OnInit } from '@angular/core';
import { MessagingService } from '../services/messaging.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})
//producer
export class HomeComponent implements OnInit {
  constructor(private ms:MessagingService) { }

  sendRequest(){
      this.ms.sendRequest('Bank of America')
  }
  clearRequest(){
      this.ms.clearRequest()
  }
  ngOnInit() { }
}
