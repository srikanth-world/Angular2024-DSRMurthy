import { Component, OnDestroy, OnInit } from '@angular/core';
import { MessagingService } from './services/messaging.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-notifier',
  template: `
  <div>
    <h3>I am notifier component</h3>
    @if(response){
    <div class="alert  alert-success">
       <h4 class="text-warning">{{response.data}}</h4>
   </div>
    }
</div>
  `
})
//consumer
export class NotifierComponent implements OnInit , OnDestroy{
  constructor(private ms:MessagingService) { }
  response:any
  subsriber:Subscription | undefined


  ngOnInit():void {
     this.subsriber=this.ms.getStockInfo().subscribe( (resp:any)=>{
      this.response=resp
     })
  }

  ngOnDestroy(): void {
      this.subsriber?.unsubscribe
  }
}
