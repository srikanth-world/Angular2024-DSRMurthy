import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Observable, Subject} from 'rxjs'

//chat server
@Injectable({providedIn: 'root'})
export class MessagingService {
  constructor(private http:HttpClient) { }
  private subject=new Subject<any>()

  //producer methods
  sendRequest(stockSymbol:string){
    //this.http.get(url+msg)  (Stock service) - web socket subscrition
    this.subject.next({data:`Stock price for ${stockSymbol} is $588.56`})
  }
   //producer Method
   clearRequest(){
    this.subject.next({})
   }

  //consumer methods
   getStockInfo():Observable<any>{
       return this.subject.asObservable()
   }
}
