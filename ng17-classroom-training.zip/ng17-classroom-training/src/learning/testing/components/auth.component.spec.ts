import { AuthService } from "../services/auth.service";
import {AuthComponent} from'./auth.component'

describe( 'Integration - auth service with component',()=>{
  it('isAuth test',()=>{
    const auth=new AuthService()
    const comp=new AuthComponent(auth)
    //localStorage.setItem('sso','1234')
    let actual=comp.needsLogin()
    expect(actual).toBeTruthy()
  })
}
)
