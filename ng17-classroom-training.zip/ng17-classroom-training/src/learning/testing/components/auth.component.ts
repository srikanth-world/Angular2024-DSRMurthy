import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-auth',
  template: `
  <a [hidden]="needsLogin()">Login</a>
  `
})

export class AuthComponent implements OnInit {
  constructor(private auth:AuthService) {
    localStorage.setItem('sso','1234')
   }

  needsLogin():boolean{
   return this.auth.isAuthenticated()
  }
  ngOnInit() { }
}
