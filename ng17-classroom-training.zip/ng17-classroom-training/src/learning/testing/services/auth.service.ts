import { Injectable } from '@angular/core';

@Injectable({providedIn: 'root'})
export class AuthService {
  constructor() {

  }

  isAuthenticated():boolean{
    //localStorage.setItem('sso','1234')
     return !!localStorage.getItem('sso')
  }

}
