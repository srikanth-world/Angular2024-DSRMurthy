import {AuthService} from './auth.service'

describe( 'Service : Auth',()=>{
  let service:AuthService
  beforeAll( ()=>{
    console.log('Fired only once')
  })
  afterAll( ()=>{
    console.log('clean data or destroy resources')
  })

  beforeEach( ()=>{
    service=new AuthService()
    console.log("before each fired")
  })
  afterEach( ()=>{
    console.log('after each fired')
    //service=null
    localStorage.removeItem('sso')
  })


  it('should return true if sso exists',()=>{
    localStorage.setItem('sso','1234') //mock
    expect(service.isAuthenticated()).toBeTruthy()

  })
  it('should return false if sso DOES not exist',()=>{
    expect(service.isAuthenticated()).toBeFalsy()
  })
})
