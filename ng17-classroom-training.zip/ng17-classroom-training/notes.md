ES5: global/local,block scope

let x=10
function show(){
  let y=20
  if(true){
    let z=30
  }
  console.log(z) //undefined
}

show()

ES6: object oriented lang:  16 new features
let,const,FAT,class , extends ,rest , spread, Promise ......

Typescript : superset of ES6 16+ 
POOL : interfaces,abstract, generics,type,enums , public,private,protected
let x<int>="murthy"

let x=10
x="murthy"

const x={ name:murthy}
x.name="murthy"

in js, number,string,boolean  - called primitive types - call by value- immutable

var x=10
var y=x  //copy will be passed
y=20
console.log(x)//10

[],{}, call by ref.  = mutable 

var obj1={x:10}
var obj2=obj1
obj2.x=20
console.log(obj1.x)//20

var storedata={ customers:[{},{}....],sso:62332,Products:[{},{}]} 
//undo/redo/time travel debugging

var obj2=Object.assign({},obj1)
obj2.x=20   immutable

obj2={...obj1} //spread operator
sync.    vs   async   calls
blocking     non-blocking
promise  vs observable vs async/await

async function LRT(){
      const result=await  sendbulkmail()
      console.log(result)

}

async function upload(){
  try{
  await upload(bigdata)
  await download(otherdata)
  console.log('all tasks completed ')
  }catch(e){console.log(e)}
}

LRT()
upload()


http://api.openweathermap.org/data/2.5/weather?q=hyderabad&units=imperial&appid=ca3f6d6ca3973a518834983d0b318f73


1. live data(stream) with ReactiveFormsModule and HttpClientModule.

2. Node express (REST api) to perform CRUD with angular client
using httpclient (get,post,put,delete)
cors issue

3. rx js subscription with subject (intercomponent communcation)


FormsModule  vs ReactiveFormsModule
ngModel         vs   RX JS - FormControl, FormBuilder, Validator, ...

Project:
REST API: CRUD : get/post/put/delete 
springRest 
Web API
Django/flask

node js :
      express - rest api


http.get with HttpClient


@app.get('/upload')
async def upload(){
  await  request.post(data)
}

http.get(url)
http interceptors
request :HttpRequest  - onRequest(url)
   
response: HttpResponse -onResponse()


Guard: interceptor with rules and roles
functional programming

canActivate
canDeactivate
canLoad
resolve()
.......
==
===================================================
Testing:
   Checking the quality of code with correctness of the func.
  
CI/CD : pipelines  - Testing

3types:
  1. Unit testing 
  2. integrated
  3.e2e testing 

  TDD vs BDD

  1. write the test code - test spec.-> req. doc   
  2. write the func.
  3. run the test  - pass/fail

  manually or automatic - KARMA, Jasmine

  xyz.spec.ts   

  Vanilla   vs ATB
=========================
ng-content:

Content Projection: HTML /css+ content from parent to child. Child can display the content in designated placeholder/spot/slots.

@Input()    //state management (UDF)
info:string

<ng-content/>    child  UI logic
multiple-slot




Feedback link :
https://tcheck.co/2HYTj9


PFB : Post test link for Adv Angular training.
https://app.mymapit.in/code4/tiny/ZrxQJh


Angular Material:

https://drive.google.com/drive/folders/1PQbzXHb2BDJNVm4Awz8QqcWqajuh-8ms?usp=sharing

mail: dsrmurthysoftware@gmail.com
ph: 98480 11641


3.50pm to 4.00p : Feedback   

4pm to 4.20pm : tea break

4.20pm to 4.45pm: Post test

Resume session at 4.45: XSS/CSP


==========================================================
XSS / CSP
Cross size scripting attack (XSS)
Content Security Policy

injection attack
reg. form email,phone
<script>alert("xss attack")</script>

DOM elements , input   text, <textarea>

built-in xss protection features in angular


